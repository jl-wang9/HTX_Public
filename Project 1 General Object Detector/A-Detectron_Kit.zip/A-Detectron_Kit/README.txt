About files:

RUN_ME.py
- The all in one programme! Run using "python RUN_ME.py" in command prompt.
- Recommended method to train, validate, test your AI model.

Detectron_MAIN.ipynb
- Notebook to run to train, validate, test your AI model.

Detectron_InferenceOnly.ipynb
- This notebook is used for testing your AI model.


################################################################
Instructions:

- Do not modify this folder

- Copy paste this folder into your own directory before use. This folder will be your "root" folder for the programme
- Put in your own datasets into the datasets folder (Each train_val and test folder need to have at least 2 images!)
